#! /usr/bin/env bash

wget https://pjreddie.com/media/files/yolov3-tiny.weights 
